<?php 
    $page_title="ICBM Wiki";
    $title ="ICBM Wiki";
    $sub_title = "Minecraft Missile Mod";
    include($_SERVER['DOCUMENT_ROOT'] . "/php/top.wiki.php");
   
?>   
<p style="padding:0px;"> <strong>Note:</strong> Wiki is not updated often, content may be outdated.</p>
<p style="padding:0px;"> <strong>Note:</strong> For up to date recipes use mods like <a href="http://chickenbones.net/Pages/links.html">NEI</a> or <a href="http://www.curse.com/mc-mods/minecraft/238222-just-enough-items-jei">JEI</a> for recipes</p>
</br>