<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/wiki.top.php"); ?>

<script>
var embeds = ['https://www.youtube.com/embed/FrdqMIuPQ0w?rel=0&amp;controls=0&amp;showinfo=0'];
</script>

<link rel="stylesheet" type="text/css" href="../../wikistyle.css">
<h1> Warhead - Fire Bomb Fit </h1>
<h2  id="warhead"> </h2>
<br/>
<table>
<tr>
    <td class="arrowleft">
        <input id="arrowleft" type="image" src="../../../../../img/icbm/buranku.png" width="70" height="315"/>
    </td>
    <td class="video">
        <iframe id="iframe" width="420" height="315" frameborder="0" allowfullscreen></iframe>
    </td>
    <td class="content">
    <div id="1" style="display:none">
        <p>They say you're never suppose to play fire. However, if you're launching a Fire Bomb from a Missile Launcher, are you playing with fire or missiles? This Fire Bomb Fit, with a small radius of one, will set any block on fire when targeted. That wooden bridge that your friend built looks like a nice testing location.</p>
      	<br/>
        <h2>Recipe</h2>
        <img class="recipeimage" src="../../../../../img/icbm/recipe-microwarhead-fire-bomb.png" width="109" height="109" alt="Micro Warhead - Fire Bomb Fit recipe"/>
        <br/>
        <p class="recipedescription">
        A Micro Warhead, Coal and a recommended common household item. Gunpowder.
        </p>
    </div>
    </td>
    <td class="arrowright">
        <input id="arrowright" type="image" src="../../../../../img/icbm/buranku.png" width="70" height="315"/>
    </td>
</tr>
</table>
<br/>
<div class="history">
    <h2>History</h2>
    <br/>
    <p>#2.3.0 - Added in the new 1.7.10 release</p>
    <br/>
</div>   

<script src="../../../../../js/wikicontentchanger.js"></script>
    
<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/content.php"); ?>
<?php include($_SERVER['DOCUMENT_ROOT'] . "/php/bottom.php"); ?>