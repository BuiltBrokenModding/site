<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/wiki.top.php"); ?>
<script>
var embeds = ['https://www.youtube.com/embed/GImu6621eKs?rel=0&amp;controls=0'];
</script>



<link rel="stylesheet" type="text/css" href="../../wikistyle.css">
<h1> Warhead - Antimatter Fit </h1>
<h2  id="warhead"> </h2>
<br/>
<table>
<tr>
    <td class="arrowleft">
        <input id="arrowleft" type="image" src="../../../../../img/icbm/buranku.png" width="70" height="315"/>
    </td>
    <td class="video">
        <iframe id="iframe" width="420" height="315" frameborder="0" allowfullscreen></iframe>
    </td>
    <td class="content">
    <div id="1" style="display:none">
        <p>A Micro Warhead fit with an antimatter explosive. Devastate your desired area with a three block radius of destruction. Great for those specific three-block areas that you just can't stand. For example, your friend's house.</p>
        <br/>
        <h2>Recipe</h2>
        <img id="recimg" src="../../../../../img/icbm/recipe-microwarhead-antimatter.png" class="recipeimage" src="" width="108" height="108" alt="Micro Warhead - Antimatter Fit recipe"/>
        <br/>
        <p class="recipedescription">This is crafted with two Eye of Ender, one Netherstar, and one Microwarhead.
        
        </p>
        <br/>
    </div>
    </td>
    <td class="arrowright">
        <input id="arrowright" type="image" src="../../../../../img/icbm/buranku.png" width="70" height="315"/>
    </td>
</tr>
</table>
<br/>
<div class="history">
    <h2>History</h2>
    <br/>
    <p>#2.3.0 - Added in the new 1.7.10 release</p>
    <br/>
</div>
    
<script src="../../../../../js/wikicontentchanger.js"></script>
    
<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/content.php"); ?>
<?php include($_SERVER['DOCUMENT_ROOT'] . "/php/bottom.php"); ?>