<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/wiki.top.php"); ?>

<script>
var embeds = ['https://www.youtube.com/embed/X-MrPbv3lsg?rel=0&amp;controls=0&amp;showinfo=0'];
</script>

<link rel="stylesheet" type="text/css" href="../../wikistyle.css">
<h1> Warhead - Flash Fire Fit </h1>
<h2  id="warhead"> </h2>
<br/>
<table>
<tr>
    <td class="arrowleft">
        <input id="arrowleft" type="image" src="../../../../../img/icbm/buranku.png" width="70" height="315"/>
    </td>
    <td class="video">
        <iframe id="iframe" width="420" height="315" frameborder="0" allowfullscreen></iframe>
    </td>
    <td class="content">
    <div id="1" style="display:none">
        <p>The odds of a flash flood coming in to save your friends statue of himself burning is pretty low. The Flash Fire Fit, with a radius of two, creates fire at your desired location. Launch with a Missile Launcher for direct hits.</p>
     	 <br/>
        <h2>Recipe</h2>
        <img class="recipeimage" src="../../../../../img/icbm/recipe-microwarhead-flash-fire.png" width="108" height="108" alt="Micro Warhead - Flash Fire Fit recipe"/>
        <br/>
        <p class="recipedescription">
        Grab that blaze rod you were going to burn your friend's house down with. Fit it onto the Micro Warhead instead for a little more fun.
    	</p>
    </div>
    </td>
    <td class="arrowright">
        <input id="arrowright" type="image" src="../../../../../img/icbm/buranku.png" width="70" height="315"/>
    </td>
</tr>
</table>
<br/>
<div class="history">
    <h2>History</h2>
    <br/>
    <p>#2.3.0 - Added in the new 1.7.10 release</p>
    <br/>
</div>
    
<script src="../../../../../js/wikicontentchanger.js"></script>
    
<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/content.php"); ?>
<?php include($_SERVER['DOCUMENT_ROOT'] . "/php/bottom.php"); ?>