<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/wiki.top.php"); ?>

<script>
var embeds = ['https://www.youtube.com/embed/87vlED5D-_Y?rel=0&amp;controls=0&amp;showinfo=0'];
</script>


<link rel="stylesheet" type="text/css" href="../../wikistyle.css">
<h1> Warhead - Ender Blocks Fit </h1>
<h2  id="warhead"> </h2>
<br/>
<table>
<tr>
    <td class="arrowleft">
        <input id="arrowleft" type="image" src="../../../../../img/icbm/buranku.png" width="70" height="315"/>
    </td>
    <td class="video">
        <iframe id="iframe" width="420" height="315" frameborder="0" allowfullscreen></iframe>
    </td>
    <td class="content">
    <div id="1" style="display:none">
        <p>A Micro Warhead that harnesses the power of the don't-get-to-know-too-well enderman's teleporting ability. This missile will teleport blocks to a random location rather than destroying them. Great for "misplacing" a friend's chest.</p>
        <br/>
        <h2>Recipe</h2>
        <img class="recipeimage" src="../../../../../img/icbm/recipe-microwarhead-ender-blocks.png" width="108" height="108" alt="Micro Warhead - Ender Blocks Fit recipe" width="108" height="108" alt="Micro Warhead - Endothermic Fit recipe"/>
        <br/>
        <p class="recipedescription">
        Craft this Micro Warhead with a Gold Nugget, an Ender Pearl, and a Micro Warhead.
        </p>
        <br/>
    </div>
    </td>
    <td class="arrowright">
        <input id="arrowright" type="image" src="../../../../../img/icbm/buranku.png" width="70" height="315"/>
    </td>
</tr>
</table>
<br/>
<div class="history">
    <h2>History</h2>
    <br/>
    <p>#2.3.0 - Added in the new 1.7.10 release</p>
    <br/>
</div>
    
<script src="../../../../../js/wikicontentchanger.js"></script>

<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/content.php"); ?>
<?php include($_SERVER['DOCUMENT_ROOT'] . "/php/bottom.php"); ?>