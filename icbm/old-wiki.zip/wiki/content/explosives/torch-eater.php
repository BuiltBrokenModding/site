<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/wiki.top.php"); ?>

<script>
var embeds = ['https://www.youtube.com/embed/VnecM0YMUBY?rel=0&amp;controls=0&amp;showinfo=0'];
</script>

<link rel="stylesheet" type="text/css" href="../../wikistyle.css">
<h1> Warhead - Torch Eater </h1>
<h2  id="warhead"> </h2>
<br/>
<table>
<tr>
    <td class="arrowleft">
        <input id="arrowleft" type="image" src="../../../../../img/icbm/buranku.png" width="70" height="315"/>
    </td>
    <td class="video">
        <iframe id="iframe" width="420" height="315" frameborder="0" allowfullscreen></iframe>
    </td>
    <td class="content">
    <div id="1" style="display:none">
        <p>Can't quite get to that chest full of Diamonds in your friends house? Is he noticing you a little more after you threw an antimatter at his dirt house, burned down his wood house, and set his backyard on fire senpai? The Torch Eater Fit is what you're looking for. This will destroy all torches within a two block radius. Sneak around your friends base with ease knowing that his attention will be focused on the countless number of spawning zombies in his bedroom.</p>
      <br/>
        <h2>Recipe</h2>
        <img class="recipeimage" src="../../../../../img/icbm/recipe-microwarhead-torch-eater.png" width="108" height="108" alt="Micro Warhead - Endothermic Fit recipe"/>
        <br/>
        <p class="recipedescription">
        Make yourself a Fermented Spider Eye, and clump it with an Eye of Ender and a Micro Warhead. You know, the usual items that are great for parties.
        </p>
    </div>
    </td>
    <td class="arrowright">
        <input id="arrowright" type="image" src="../../../../../img/icbm/buranku.png" width="70" height="315"/>
    </td>
</tr>
</table>
<br/>
<div class="history">
    <h2>History</h2>
    <br/>
    <p>#2.3.0 - Added in the new 1.7.10 release</p>
    <br/>
</div>

<script src="../../../../../js/wikicontentchanger.js"></script>
    
<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/content.php"); ?>
<?php include($_SERVER['DOCUMENT_ROOT'] . "/php/bottom.php"); ?>