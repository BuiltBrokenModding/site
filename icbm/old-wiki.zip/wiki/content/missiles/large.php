<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/wiki.top.php"); ?>    
    <h2>Lage Missiles</h2>
    <p>Name in game as the ICBM, this is the largest missile in the game. Standing 60 blocks tall with the power to destory an entire area of the map.</p>
    </br>
    </br>
    </br>
    <h2>History</h2>
    <p>#2.3.0 - Added in the 1.7.10 release</p>
    </br>
    
<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/content.php"); ?>
<?php include($_SERVER['DOCUMENT_ROOT'] . "/php/bottom.php"); ?>
				
