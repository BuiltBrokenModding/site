<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/wiki.top.php"); ?>       
    <h2>Small Missiles</h2>
    <p>Two block tall <a href="https://en.wikipedia.org/wiki/Missile">missile</a> that carries a small payload and is used for simple task. Has a limited range and guidance ability.</p>
    <img src="../../../../../img/icbm/smallMissile/launcher.png">
    <h3>Crafting</h3>
    <p>First step is to craft the missile casing</p>
    <img src="../../../../../img/icbm/smallMissile/recipe.png">
    <p>Then use the <a href="/pages/icbm/wiki/content/machines/workstation.php">workstation</a> to add the engine, guidance, and warhead.</p>
    </br>
    </br>
    </br>
    <h2>History</h2>
    <p>#2.3.0 - Added in the new 1.7.10 release</p>
    </br>
    
<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/content.php"); ?>
<?php include($_SERVER['DOCUMENT_ROOT'] . "/php/bottom.php"); ?>
				
