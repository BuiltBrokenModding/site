<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/wiki.top.php"); ?>        
    <h2>Micro Missiles</h2>
    <p>Small rocket designed to be fire from the <a href="/pages/icbm/wiki/content/tools/rocketlauncher.php">rocket launcher</a>. Can support 1 explosive item crammed into warhead.</p>
    </br>
    </br>
    </br>
    <h2>History</h2>
    <p>#2.3.0 - Added in the 1.7.10 release</p>
    </br>
    
<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/content.php"); ?>
<?php include($_SERVER['DOCUMENT_ROOT'] . "/php/bottom.php"); ?>
				
