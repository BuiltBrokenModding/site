<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/wiki.top.php"); ?>    
  
    <h2>Medium Missiles</h2>
    <p>Slighly larger than a normal missile allowing for a large payload to be sent.</p>
    </br>
    </br>
    </br>
    <h2>History</h2>
    <p>#2.3.0 - Added in the 1.7.10 release</p>
    </br>
    
<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/content.php"); ?>
<?php include($_SERVER['DOCUMENT_ROOT'] . "/php/bottom.php"); ?>
				
