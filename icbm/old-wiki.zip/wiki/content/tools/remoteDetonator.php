<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/wiki.top.php"); ?>    
<h2> Remote Detonator </h2>
<p> The remote detonator is used to wireless fire missile silos connected to a command controller. </p>
<img src="\img\icbm\remoteDetonator.png" alt="" style="max-width:100%; height:auto;"/>
<img src="\img\icbm\recipe-remote-detonator.png" alt="" style="max-width:100%; height:auto;"/>
<h3> Encoding </h3>
<p>The remote detonator needs to be encode in order to send firing commands. This can be done currently threw the Silo Display GUI after selecting a missile silo.</p>

<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/content.php"); ?>
<?php include($_SERVER['DOCUMENT_ROOT'] . "/php/bottom.php"); ?>