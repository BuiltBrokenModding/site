<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/wiki.top.php"); ?>    
<h2> GPS Data Chip </h2>
<img src="../../../../../img/icbm/gpsdatachip.png" alt="Data Chip" style="width:40%;height:40%;">
<p> GPS, global position sytstem, version of the <a href="/pages/icbm/wiki/content/tools/datachip.php">data chip</a> is used to store world locations. This way the location can be transfered to machines like missile <a href="/pages/icbm/wiki/content/machines/silo.php">silos</a>. Shift-right click the ground will save the location, right click will transfer the location.</p>

<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/content.php"); ?>
<?php include($_SERVER['DOCUMENT_ROOT'] . "/php/bottom.php"); ?>