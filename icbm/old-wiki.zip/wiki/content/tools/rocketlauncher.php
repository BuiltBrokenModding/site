<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/wiki.top.php"); ?>    
<h2> Rocket Launcher </h2>
<p>The rocket launcher is a hand held device enabling you to launch rockets in your inventory. </p>
<br>
<img src="\img\icbm\rocketLauncher\rocketLauncher.png" alt="" style="max-width:100%; height:auto;"/>
<br>
<p>To create a rocket launcher, follow this recipe:</p>
<br>
<img src="\img\icbm\rocketLauncher\recipe.png" alt="" style="max-width:100%; height:auto;"/>
<br>
<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/content.php"); ?>
<?php include($_SERVER['DOCUMENT_ROOT'] . "/php/bottom.php"); ?>