<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/wiki.top.php"); ?>    
<h2> Gunpowder Charge </h2>
<p> Used in missile construction </p>
<br>
<img src="\img\icbm\gunpwoderCharge.png" alt="" style="max-width:50%; height:auto;"/>
<br>
<p>Craft this item following this recipe:</p>
<br>
<img src="\img\icbm\gunpwoderCharge_recipe.png" alt="" style="max-width:50%; height:auto;"/>
<br>
<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/content.php"); ?>
<?php include($_SERVER['DOCUMENT_ROOT'] . "/php/bottom.php"); ?>