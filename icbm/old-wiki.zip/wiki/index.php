<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/wiki.top.php"); ?>    
    <h2>What is ICBM?</h2>
    <p>ICBM stands for <a href="https://en.wikipedia.org/wiki/Intercontinental_ballistic_missile">Intercontinental ballistic missile</a> and thus is based in explosives. However, it can be used for more than destroying your enemies.</p>
    </br>
    
<?php include($_SERVER['DOCUMENT_ROOT'] . "/pages/icbm/wiki/content.php"); ?>
<?php include($_SERVER['DOCUMENT_ROOT'] . "/php/bottom.php"); ?>
				
